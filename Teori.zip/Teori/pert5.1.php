<?php

    $nama_mhs = "Chanyeol";
    $admin = "Allya";

    echo "Hello ". $nama_mhs. " <br> Selamat Datang, saya ". $admin  . " <br> Semoga sehat selalu";


?>

<html>
    <head>
        <title>

        </title>
    </head>
    <body>
        <br>
        Calon Pacar Saya...
    </body>
</html>
