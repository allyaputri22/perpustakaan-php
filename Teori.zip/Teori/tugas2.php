<?php
    //membuat variable
    $nama_mhs = "Park Chanyeol";
    $nama_saya ="Allya";

    if($nama_mhs == "Park Chanyeol"){
        $jenis_kelamin = "Laki-Laki" ;

    }else if($nama_aaya == "Allya"){
        $jenis_kelamin = "Perempuan" ;

    }else{
        $jenis_kelamin = "??";
    }

    echo "Hallo " . $nama_mhs .  " <br> Selamat Datang <br> Saya " . $nama_saya."
          <br> Jenis kelamin kamu adalah ". $jenis_kelamin;

?>


<html>
   <title>
   </title> 
    <body>
        <br>
        Kamu adalah Calon Pacar Saya. Oke.
    </body>
   
</html>