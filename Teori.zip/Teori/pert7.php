<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <form action ="proses_pert7.php" method ="POST"> 
        NPM : 
        <input type ="text" name="npm" value=""></input> <br>
        NILAI : 
        <input type ="text" name="nilai" value=""></input> <br>
        ULANGI :
        <input type ="text" name="ulangi" value=""></input> <br>

        <button type ="submit" name ="prosesdata">
            PROSES DATA
        </button>

    </form>
</body>
</html>