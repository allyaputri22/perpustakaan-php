<?php

 $nama_mhs = "Chanyeol";
 $admin = "Allya";

 if($nama_mhs == "Chanyeol"){
    $jenis_kelamin = "Laki-laki";
 }else if ($nama_mhs == "Allya"){
    $jenis_kelamin = "Perempuan";
 }else{
    $jenis_kelamin = "??";
 }

 echo "Hello ". $nama_mhs. " <br> Selamat Datang, saya ". $admin  . " <br> Semoga sehat selalu". "<br> Jenis kelamin kamu adalah ".$jenis_kelamin;



    // // $nama = "Chanyeol";
    // // $calon = "Allya";

    // // echo "Hello ". $nama. " Calon pacar ". $calon  . " <br> Semoga sehat selalu";

    // $calon = ["Chanyeol","D.O","Baekhyun","Kai","Suho","Sehun"];
    // $pacar = array("1","2","3");

    // //modifikasi array
    // $calon  [0] = "Park Chanyeol";

    // //menampilkan struktur array
    // // var_dump($calon);
    // // var_dump($pacar);

    // //menampilkan data array dalam bentuk list
    // echo "<ul>";
    //     for ($i=0; $i < count($calon); $i++) { 
    //         echo "<li>" . $calon[$i] . "</li>";
    //     }

    // echo "</ul>";


?>

<html>
    <head>
        <title>

        </title>
    </head>
    <body>
        <br>
        Calon Pacar Saya...
    </body>
</html>


